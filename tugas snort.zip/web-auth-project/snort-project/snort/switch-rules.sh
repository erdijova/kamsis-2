#!/bin/sh
set -eu

RULE_DIR="/etc/snort/rules"
MODE="${1:-all}"

case "$MODE" in
  all)
    cat "$RULE_DIR/local.rules" "$RULE_DIR/community.rules" > "$RULE_DIR/active.rules"
    ;;
  local)
    cp "$RULE_DIR/local.rules" "$RULE_DIR/active.rules"
    ;;
  community)
    cp "$RULE_DIR/community.rules" "$RULE_DIR/active.rules"
    ;;
  one-local)
    cp "$RULE_DIR/local-one.rules" "$RULE_DIR/local.rules"
    cp "$RULE_DIR/local.rules" "$RULE_DIR/active.rules"
    ;;
  restore-local)
    cp "$RULE_DIR/local-full.rules" "$RULE_DIR/local.rules"
    cp "$RULE_DIR/local.rules" "$RULE_DIR/active.rules"
    ;;
  *)
    echo "Mode tidak dikenal: $MODE" >&2
    echo "Pakai: all | local | community | one-local | restore-local" >&2
    exit 1
    ;;
esac

echo "Mode rule aktif: $MODE"
wc -l "$RULE_DIR/active.rules"
