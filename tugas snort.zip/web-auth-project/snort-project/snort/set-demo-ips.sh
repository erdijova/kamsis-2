#!/bin/sh
set -eu

CONF="/etc/snort/snort.conf"
ATTACKER_IP="${1:-any}"
TARGET_IP="${2:-[172.20.0.2,172.20.0.4]}"
TMP_CONF="$(mktemp)"

sed \
  -e "s|^ipvar ATTACKER_IP .*|ipvar ATTACKER_IP ${ATTACKER_IP}|" \
  -e "s|^ipvar TARGET_IP .*|ipvar TARGET_IP ${TARGET_IP}|" \
  "$CONF" > "$TMP_CONF"

cat "$TMP_CONF" > "$CONF"
rm -f "$TMP_CONF"

echo "ATTACKER_IP sekarang: ${ATTACKER_IP}"
echo "TARGET_IP sekarang: ${TARGET_IP}"
echo "Restart container snort agar perubahan dipakai."
