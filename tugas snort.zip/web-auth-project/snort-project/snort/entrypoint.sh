#!/bin/sh
set -eu

WEB_IP="${WEB_IP:-172.20.0.2}"
DB_IP="${DB_IP:-172.20.0.3}"
SNORT_IFACE="${SNORT_IFACE:-eth0}"

sysctl -w net.ipv4.ip_forward=1 >/dev/null

iptables -C INPUT -p tcp --dport 3306 -j REJECT 2>/dev/null || \
  iptables -A INPUT -p tcp --dport 3306 -j REJECT

iptables -C INPUT -p tcp -m multiport --dports 80,443 -j ACCEPT 2>/dev/null || \
  iptables -A INPUT -p tcp -m multiport --dports 80,443 -j ACCEPT

socat TCP-LISTEN:80,fork,reuseaddr TCP:"${WEB_IP}":80 &
socat TCP-LISTEN:443,fork,reuseaddr TCP:"${WEB_IP}":443 &

echo "ACL aktif: port 80/443 diproxy ke web ${WEB_IP}, port 3306 dari luar ditolak."
echo "Snort memonitor interface ${SNORT_IFACE}."

exec snort -A console -q -k none -c /etc/snort/snort.conf -i "${SNORT_IFACE}" -l /var/log/snort
