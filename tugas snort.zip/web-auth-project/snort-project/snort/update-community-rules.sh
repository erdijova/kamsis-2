#!/bin/sh
set -eu

RULE_URL="${RULE_URL:-https://www.snort.org/downloads/community/community-rules.tar.gz}"
WORKDIR="$(mktemp -d)"
TARGET="/etc/snort/rules/community.rules"

cleanup() {
  rm -rf "$WORKDIR"
}
trap cleanup EXIT

echo "Mengunduh rule komunitas dari ${RULE_URL}"
wget -q -O "${WORKDIR}/community-rules.tar.gz" "${RULE_URL}"
tar -xzf "${WORKDIR}/community-rules.tar.gz" -C "${WORKDIR}"

FOUND="$(find "${WORKDIR}" -name community.rules -type f | head -n 1)"
if [ -z "$FOUND" ]; then
  echo "community.rules tidak ditemukan di arsip unduhan" >&2
  exit 1
fi

cp "$FOUND" "$TARGET"
echo "Rule komunitas diperbarui di ${TARGET}"
