<?php
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    header("Location: https://localhost:8443" . $_SERVER['REQUEST_URI']);
    exit();
}

session_start();

// koneksi ke database
$conn = new mysqli("db", "root", "root", "auth_db", 3306);

// cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // ambil & bersihkan input
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    // validasi input
    if (empty($username) || empty($password)) {
        $message = "Username dan password tidak boleh kosong!";
    } elseif (strlen($username) < 3) {
        $message = "Username minimal 3 karakter!";
    } elseif (strlen($password) < 3) {
        $message = "Password minimal 3 karakter!";
    } else {

        // hash password (sudah termasuk salt)
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // prepared statement (anti SQL Injection)
        $stmt = $conn->prepare("INSERT INTO users (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hashed_password);

    try {

        if ($stmt->execute()) {
            $message = "Registrasi berhasil!";
        }

    } catch (mysqli_sql_exception $e) {

        if ($e->getCode() == 1062) {
             $message = "Username sudah digunakan!";
        } else {
             $message = "Terjadi kesalahan pada sistem!";
        }
}

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Register</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
<h2>Register</h2>

<form method="POST" action="">
    Username: <input type="text" name="username" maxlength="30" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <button type="submit">Daftar</button>
</form>

<!-- tampilkan pesan dengan proteksi XSS -->
<p><?php echo htmlspecialchars($message); ?></p>

<br>
<p>Sudah punya akun? <a href="https://localhost:8443/login.php">Login</a></p>

</div>

</body>
</html>