<?php
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    header("Location: https://localhost:8443" . $_SERVER['REQUEST_URI']);
    exit();
}

session_start();

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}
?>

<h2>Selamat datang, <?php echo htmlspecialchars($_SESSION["username"]); ?>

<a href="logout.php">Logout</a>