<?php
// Paksa HTTPS
if (!isset($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    header("Location: https://localhost:8443" . $_SERVER['REQUEST_URI']);
    exit();
}

session_start();

// =======================
// KONFIGURASI
// =======================
$max_attempts = 2;
$lock_time = 5; 

// =======================
// INISIALISASI SESSION
// =======================
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
}

if (!isset($_SESSION['lock_time'])) {
    $_SESSION['lock_time'] = 0;
}

// =======================
// CEK LOCK
// =======================
if ($_SESSION['lock_time'] > time()) {
    $remaining = $_SESSION['lock_time'] - time();
    die("Akun dikunci. Coba lagi dalam $remaining detik.");
}

// =======================
// KONEKSI DATABASE
// =======================
$conn = new mysqli("db", "root", "root", "auth_db", 3306);

if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$message = "";

// =======================
// PROSES LOGIN
// =======================
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Delay untuk memperlambat brute force
    sleep(1);

    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    // Prepared Statement (anti SQL Injection)
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        // Verifikasi password
        if (password_verify($password, $hashed_password)) {

            // RESET jika berhasil
            $_SESSION['login_attempts'] = 0;
            $_SESSION['lock_time'] = 0;

            // Regenerate session (anti session hijacking)
            session_regenerate_id(true);

            $_SESSION["username"] = $username;

            header("Location: https://localhost:8443/dashboard.php");
            exit();

        } else {
            $_SESSION['login_attempts']++;
            $message = "Password salah!";
        }
    } else {
        $_SESSION['login_attempts']++;
        $message = "Username tidak ditemukan!";
    }

    // =======================
    // CEK BATAS LOGIN
    // =======================
    if ($_SESSION['login_attempts'] >= $max_attempts) {
        $_SESSION['lock_time'] = time() + $lock_time;
        $message = "Terlalu banyak percobaan! Akun dikunci";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Aman</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="container">
<h2>Login</h2>

<form method="POST" action="">
    Username: <input type="text" name="username" maxlength="30" required><br><br>
    Password: <input type="password" name="password" required><br><br>
    <button type="submit">Login</button>
</form>

<br>
<p>Belum punya akun? <a href="https://localhost:8443/register.php">Buat akun</a></p>

<!-- tampilkan pesan dengan proteksi XSS -->
<p><?php echo htmlspecialchars($message); ?></p>

</div>

</body>
</html>
