<?php
header("Location: login.php");
exit();

$host = "db";
$user = "root";
$pass = "root";
$db   = "auth_db";

// inisialisasi koneksi
$conn = mysqli_init();

// MATIKAN SSL (ini penting!)
mysqli_options($conn, MYSQLI_OPT_SSL_VERIFY_SERVER_CERT, false);

// koneksi ke database
$conn->real_connect($host, $user, $pass, $db, 3306);

// cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

echo "Koneksi ke database berhasil!";
?>