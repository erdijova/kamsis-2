#!/bin/bash
# ============================================================
# test-acl.sh
# Uji ACL (iptables) dan Snort IDS
# Jalankan DARI container lain atau host untuk test
# Usage: docker exec erdi-snort test-acl.sh [icmp|ssh|http|db|scan|flood|all]
# ============================================================

TARGET_WEB="172.20.0.10"
TARGET_DB="172.20.0.20"
TARGET_SNORT="172.20.0.15"
TEST="${1:-all}"

PASS='\033[0;32m[PASS]\033[0m'
FAIL='\033[0;31m[FAIL]\033[0m'
INFO='\033[0;36m[INFO]\033[0m'
WARN='\033[1;33m[WARN]\033[0m'

echo "========================================"
echo "  UJI ACL + SNORT IDS - Project 3"
echo "========================================"
echo ""

test_icmp() {
    echo "--- TEST 1: ICMP (Ping) ---"
    echo -e "$INFO Ping normal ke web server (5 ping)..."
    if ping -c 5 -W 2 "$TARGET_WEB" > /dev/null 2>&1; then
        echo -e "$PASS Ping normal: BERHASIL (ACL mengizinkan <5/detik)"
    else
        echo -e "$FAIL Ping normal: GAGAL (cek koneksi)"
    fi

    echo -e "$INFO Simulasi ICMP Flood (trigger Snort SID 1000001)..."
    echo "    Mengirim 20 ping cepat..."
    ping -c 20 -i 0.01 -W 1 "$TARGET_WEB" > /dev/null 2>&1
    echo -e "$WARN Flood dikirim - cek /var/log/snort/alert.log di container snort"
    echo "    Expected: [P1] ICMP FLOOD DETECTED"
    echo ""
}

test_ssh() {
    echo "--- TEST 2: SSH Rate Limit ---"
    echo -e "$INFO Test SSH ke web server (harus dibatasi ACL)..."
    for i in 1 2 3 4 5; do
        timeout 2 bash -c "echo '' | nc -w 1 $TARGET_WEB 22" > /dev/null 2>&1
        echo "    Attempt $i: koneksi ke port 22"
    done
    echo -e "$WARN 5 percobaan SSH dikirim - expected: koneksi ke-4 di-DROP oleh ACL"
    echo ""
}

test_http() {
    echo "--- TEST 3: HTTP/HTTPS ke Web Server ---"
    echo -e "$INFO Test HTTP port 80..."
    HTTP=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "http://$TARGET_WEB/")
    if [ "$HTTP" != "000" ]; then
        echo -e "$PASS HTTP port 80: dapat diakses (code: $HTTP)"
    else
        echo -e "$FAIL HTTP port 80: tidak bisa diakses"
    fi

    echo -e "$INFO Test HTTPS port 443..."
    HTTPS=$(curl -sk -o /dev/null -w "%{http_code}" --max-time 5 "https://$TARGET_WEB/")
    if [ "$HTTPS" != "000" ]; then
        echo -e "$PASS HTTPS port 443: dapat diakses (code: $HTTPS)"
    else
        echo -e "$FAIL HTTPS port 443: tidak bisa diakses"
    fi
    echo ""
}

test_db() {
    echo "--- TEST 4: Blokir Akses Langsung ke DB ---"
    echo -e "$INFO Test akses MySQL port 3306 dari Snort container..."
    echo "    (Harusnya di-BLOCK karena kita bukan 172.20.0.10)"
    timeout 3 bash -c "echo '' | nc -w 2 $TARGET_DB 3306" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "$FAIL Port 3306: TERBUKA dari snort (ACL kurang ketat!)"
    else
        echo -e "$PASS Port 3306: DIBLOKIR dari snort container (ACL OK!)"
    fi
    echo ""
}

test_portscan() {
    echo "--- TEST 5: Port Scan (trigger Snort SID 1000009) ---"
    echo -e "$INFO Menjalankan port scan ke web server..."
    nmap -sS -T4 --top-ports 50 "$TARGET_WEB" -oN /tmp/scan-result.txt > /dev/null 2>&1
    echo -e "$WARN Port scan selesai - cek alert.log untuk [P2] PORT SCAN"
    cat /tmp/scan-result.txt | grep -E "open|filtered|closed" | head -10
    echo ""
}

test_flood() {
    echo "--- TEST 6: ICMP Flood Intensif ---"
    echo -e "$WARN Mengirim 100 ping sekaligus (hping3)..."
    hping3 --icmp -c 100 --fast "$TARGET_WEB" > /dev/null 2>&1 &
    HPING_PID=$!
    sleep 3
    kill $HPING_PID 2>/dev/null
    echo -e "$WARN Flood selesai - cek notif di container snort"
    echo "    Expected alert: [P1] ICMP FLOOD DETECTED"
    echo ""
}

show_alert() {
    echo "========================================"
    echo "  ALERT LOG TERBARU (last 10 lines)"
    echo "========================================"
    ALERT_LOG="/var/log/snort/alert.log"
    if [ -f "$ALERT_LOG" ] && [ -s "$ALERT_LOG" ]; then
        tail -10 "$ALERT_LOG"
    else
        echo "  Alert log kosong atau belum ada alert"
    fi

    echo ""
    echo "  Critical alerts:"
    CRIT="/var/log/snort/critical-alerts.log"
    if [ -f "$CRIT" ] && [ -s "$CRIT" ]; then
        tail -5 "$CRIT"
    else
        echo "  Belum ada critical alert"
    fi
    echo "========================================"
}

case "$TEST" in
  icmp)   test_icmp ;;
  ssh)    test_ssh ;;
  http)   test_http ;;
  db)     test_db ;;
  scan)   test_portscan ;;
  flood)  test_flood ;;
  all)
    test_icmp
    test_http
    test_db
    test_portscan
    show_alert
    ;;
  *)
    echo "Usage: test-acl.sh [icmp|ssh|http|db|scan|flood|all]"
    ;;
esac
