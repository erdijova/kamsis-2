#!/bin/bash
# ============================================================
# notify.sh
# Monitor alert.log Snort dan kirim notifikasi OTOMATIS
# saat ada serangan terdeteksi
# ============================================================

ALERT_LOG="/var/log/snort/alert.log"
NOTIFY_LOG="/var/log/snort/notify.log"

# Warna terminal
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
BOLD='\033[1m'
NC='\033[0m'

echo "[NOTIFY] Monitor dimulai - watching $ALERT_LOG"
echo "[NOTIFY] Log notifikasi: $NOTIFY_LOG"

# Tunggu file ada
while [ ! -f "$ALERT_LOG" ]; do
    sleep 1
done

# Monitor realtime
tail -F "$ALERT_LOG" 2>/dev/null | while read -r line; do

    TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')

    # Ekstrak info dari alert Snort
    # Format Snort alert: MM/DD-HH:MM:SS.usec  [**] [gid:sid:rev] msg [**] ...
    MSG=$(echo "$line" | grep -oP '\[\*\*\] \K[^\[]*' | head -1 | xargs)

    if [ -z "$MSG" ]; then
        continue
    fi

    # Tentukan level berdasarkan priority dalam pesan
    if echo "$MSG" | grep -q "\[P1\]"; then
        LEVEL="CRITICAL"
        COLOR=$RED
        ICON="🚨"
    elif echo "$MSG" | grep -q "\[P2\]"; then
        LEVEL="WARNING "
        COLOR=$YELLOW
        ICON="⚠️ "
    elif echo "$MSG" | grep -q "\[P3\]"; then
        LEVEL="INFO    "
        COLOR=$CYAN
        ICON="ℹ️ "
    elif echo "$MSG" | grep -q "\[P0\]"; then
        LEVEL="DEBUG   "
        COLOR=$GREEN
        ICON="🔍"
    else
        LEVEL="ALERT   "
        COLOR=$YELLOW
        ICON="🔔"
    fi

    # Tampilkan di terminal dengan warna
    printf "${COLOR}${BOLD}[$TIMESTAMP] [SNORT-${LEVEL}] ${ICON}  %s${NC}\n" "$MSG"

    # Tulis ke notify log
    echo "[$TIMESTAMP] [$LEVEL] $MSG" >> "$NOTIFY_LOG"

    # Aksi khusus untuk CRITICAL (P1)
    if [ "$LEVEL" = "CRITICAL" ]; then
        printf "${RED}${BOLD}"
        echo "  ╔══════════════════════════════════════════════╗"
        echo "  ║   !! SERANGAN KRITIS TERDETEKSI !!           ║"
        echo "  ║   $MSG"
        echo "  ║   Waktu: $TIMESTAMP"
        echo "  ╚══════════════════════════════════════════════╝"
        printf "${NC}"

        # Catat ke file khusus critical
        echo "[$TIMESTAMP] CRITICAL: $MSG" >> /var/log/snort/critical-alerts.log
    fi

done
