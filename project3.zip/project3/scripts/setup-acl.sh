#!/bin/bash
# ============================================================
# setup-acl.sh
# ACL menggunakan iptables
# IBS (Inbound/Bound Security) + Firewall rules
# ============================================================

echo "[ACL] Membersihkan rules lama..."
iptables -F
iptables -X
iptables -Z

# ===========================================================
# DEFAULT POLICY
# ===========================================================
iptables -P INPUT   DROP      # Default: tolak semua masuk
iptables -P FORWARD DROP      # Default: tolak semua forward
iptables -P OUTPUT  ACCEPT    # Default: izinkan semua keluar

echo "[ACL] Default policy: INPUT=DROP, FORWARD=DROP, OUTPUT=ACCEPT"

# ===========================================================
# LOOPBACK - Selalu izinkan
# ===========================================================
iptables -A INPUT -i lo -j ACCEPT
echo "[ACL] Loopback: ACCEPT"

# ===========================================================
# ESTABLISHED / RELATED - Izinkan koneksi yang sudah ada
# ===========================================================
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
echo "[ACL] Established/Related: ACCEPT"

# ===========================================================
# [IBS] RULE 1: BLOKIR ICMP FLOOD
# Izinkan max 5 ping/detik, lebih dari itu DROP
# ===========================================================
iptables -A INPUT -p icmp --icmp-type echo-request \
  -m limit --limit 5/second --limit-burst 10 \
  -j ACCEPT
iptables -A INPUT -p icmp --icmp-type echo-request -j DROP
echo "[ACL] ICMP Flood protection: max 5 ping/detik, sisanya DROP"

# Izinkan ICMP echo-reply (respons ping keluar)
iptables -A INPUT -p icmp --icmp-type echo-reply -j ACCEPT

# ===========================================================
# [IBS] RULE 2: IZINKAN HTTP/HTTPS KE WEB SERVER
# Hanya dari internal network
# ===========================================================
iptables -A INPUT -p tcp -s 172.20.0.0/24 \
  --dport 80 -j ACCEPT
iptables -A INPUT -p tcp -s 172.20.0.0/24 \
  --dport 443 -j ACCEPT
echo "[ACL] HTTP/HTTPS dari 172.20.0.0/24: ACCEPT"

# ===========================================================
# [FIREWALL] RULE 3: BLOKIR AKSES LANGSUNG KE MySQL
# DB hanya boleh diakses dari web server (172.20.0.10)
# ===========================================================
iptables -A INPUT -p tcp -s 172.20.0.10 --dport 3306 -j ACCEPT
iptables -A INPUT -p tcp --dport 3306 -j DROP
echo "[ACL] MySQL port 3306: hanya dari erdi-web (172.20.0.10)"

# ===========================================================
# [FIREWALL] RULE 4: RATE LIMIT SSH
# Max 3 koneksi SSH per menit (anti brute force)
# ===========================================================
iptables -A INPUT -p tcp --dport 22 \
  -m state --state NEW \
  -m recent --set --name SSH_TRACK
iptables -A INPUT -p tcp --dport 22 \
  -m state --state NEW \
  -m recent --update --seconds 60 --hitcount 4 --name SSH_TRACK \
  -j DROP
iptables -A INPUT -p tcp --dport 22 -j ACCEPT
echo "[ACL] SSH: rate limit max 3 koneksi/menit"

# ===========================================================
# [FIREWALL] RULE 5: IZINKAN DNS (UDP/TCP port 53)
# ===========================================================
iptables -A INPUT -p udp --dport 53 -j ACCEPT
iptables -A INPUT -p tcp --dport 53 -j ACCEPT
echo "[ACL] DNS port 53: ACCEPT"

# ===========================================================
# [FIREWALL] RULE 6: BLOKIR PORT SCANNING
# Deteksi SYN scan ke port tertutup, blokir 60 detik
# ===========================================================
iptables -A INPUT -p tcp --tcp-flags ALL NONE -j DROP
iptables -A INPUT -p tcp --tcp-flags SYN,FIN SYN,FIN -j DROP
iptables -A INPUT -p tcp --tcp-flags SYN,RST SYN,RST -j DROP
echo "[ACL] Port scan protection: NULL/XMAS/SYN-FIN scan: DROP"

# ===========================================================
# [LOG] Log semua yang di-DROP (untuk Snort capture)
# ===========================================================
iptables -A INPUT -j LOG \
  --log-prefix "[ACL-DROP] " \
  --log-level 4
iptables -A INPUT -j DROP

echo ""
echo "[ACL] ============ RULES AKTIF ============"
iptables -L -v -n --line-numbers
echo "[ACL] ======================================="
