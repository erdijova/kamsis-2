#!/bin/bash
# ============================================================
# start-snort.sh
# Entrypoint container Snort:
# 1. Setup ACL (iptables)
# 2. Jalankan Snort IDS
# 3. Monitor alert dan kirim notifikasi
# ============================================================

echo "========================================"
echo "  SNORT IDS + ACL - Project 3 (erdi)"
echo "  Network: 172.20.0.0/24"
echo "========================================"

# Deteksi interface
IFACE=$(ip -o link show | awk -F': ' '{print $2}' | grep -v lo | head -1)
echo "[*] Interface terdeteksi: $IFACE"

# Setup ACL
echo "[*] Menerapkan ACL (iptables)..."
/usr/local/bin/setup-acl.sh

# Pastikan log dir ada
mkdir -p /var/log/snort
touch /var/log/snort/alert.log

echo "[*] Memulai Snort IDS pada interface $IFACE..."
echo "[*] Config: /etc/snort/snort.conf"
echo "[*] Log   : /var/log/snort/"
echo ""

# Mulai Snort di background
snort -i "$IFACE" \
      -c /etc/snort/snort.conf \
      -l /var/log/snort \
      -A fast \
      -D \
      --daq-dir /usr/lib/daq \
      2>/var/log/snort/snort-error.log

sleep 2
echo "[*] Snort berjalan (PID: $(cat /var/run/snort_*.pid 2>/dev/null || echo 'lihat ps'))"

# Mulai monitor notifikasi di background
/usr/local/bin/notify.sh &

echo ""
echo "========================================"
echo "  SNORT AKTIF - Monitoring traffic..."
echo "  Gunakan: tail -f /var/log/snort/alert.log"
echo "========================================"

# Keep container alive & tampilkan alert realtime
tail -f /var/log/snort/alert.log
