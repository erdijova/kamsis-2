#!/bin/bash
# ============================================================
# toggle-rules.sh
# Ganti antara LOCAL rules dan COMMUNITY rules
# Usage: toggle-rules.sh [local|community|both|status]
# ============================================================

CONF="/etc/snort/snort.conf"
MODE="${1:-status}"

show_status() {
    echo "========================================"
    echo "  STATUS RULES SAAT INI"
    echo "========================================"
    LOCAL=$(grep -v "^#" "$CONF" | grep "local.rules" | grep "^include")
    COMMUNITY=$(grep -v "^#" "$CONF" | grep "community.rules" | grep "^include")

    if [ -n "$LOCAL" ]; then
        echo "  [✓ AKTIF  ] Local Rules"
    else
        echo "  [✗ nonaktif] Local Rules"
    fi

    if [ -n "$COMMUNITY" ]; then
        echo "  [✓ AKTIF  ] Community Rules (Emerging Threats)"
    else
        echo "  [✗ nonaktif] Community Rules"
    fi

    echo ""
    echo "  Local rules count    : $(grep -c "^alert" /etc/snort/rules/local.rules 2>/dev/null || echo 0)"
    echo "  Community rules count: $(grep -c "^alert\|^drop" /etc/snort/rules/community.rules 2>/dev/null || echo 0)"
    echo "========================================"
}

case "$MODE" in

  local)
    echo "[*] Mengaktifkan LOCAL rules saja..."
    # Aktifkan local.rules
    sed -i 's|^# include \$RULE_PATH/local.rules|include $RULE_PATH/local.rules|' "$CONF"
    # Nonaktifkan community.rules
    sed -i 's|^include \$RULE_PATH/community.rules|# include $RULE_PATH/community.rules|' "$CONF"
    echo "[✓] LOCAL rules: AKTIF"
    echo "[✗] COMMUNITY rules: nonaktif"
    ;;

  community)
    echo "[*] Mengaktifkan COMMUNITY rules saja..."
    # Nonaktifkan local.rules
    sed -i 's|^include \$RULE_PATH/local.rules|# include $RULE_PATH/local.rules|' "$CONF"
    # Aktifkan community.rules
    sed -i 's|^# include \$RULE_PATH/community.rules|include $RULE_PATH/community.rules|' "$CONF"
    echo "[✗] LOCAL rules: nonaktif"
    echo "[✓] COMMUNITY rules: AKTIF"
    ;;

  both)
    echo "[*] Mengaktifkan SEMUA rules (local + community)..."
    # Aktifkan keduanya
    sed -i 's|^# include \$RULE_PATH/local.rules|include $RULE_PATH/local.rules|' "$CONF"
    sed -i 's|^# include \$RULE_PATH/community.rules|include $RULE_PATH/community.rules|' "$CONF"
    echo "[✓] LOCAL rules: AKTIF"
    echo "[✓] COMMUNITY rules: AKTIF"
    ;;

  off-local)
    echo "[*] Menonaktifkan LOCAL rules..."
    sed -i 's|^include \$RULE_PATH/local.rules|# include $RULE_PATH/local.rules|' "$CONF"
    echo "[✗] LOCAL rules: nonaktif"
    ;;

  status)
    show_status
    ;;

  *)
    echo "Usage: toggle-rules.sh [local|community|both|off-local|status]"
    echo ""
    echo "  local      - Aktifkan local rules saja, matikan community"
    echo "  community  - Aktifkan community rules saja, matikan local"
    echo "  both       - Aktifkan keduanya"
    echo "  off-local  - Matikan local rules (coba matikan local rules)"
    echo "  status     - Lihat status rules saat ini"
    echo ""
    show_status
    ;;
esac

echo ""
echo "[*] Restart Snort supaya perubahan berlaku:"
echo "    pkill snort && sleep 2 && /usr/local/bin/start-snort.sh &"
