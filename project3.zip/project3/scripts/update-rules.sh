#!/bin/bash
# ============================================================
# update-rules.sh
# Update Community Rules dari Emerging Threats (ET Open)
# Manual Update - jalankan: docker exec erdi-snort update-rules.sh
# ============================================================

RULES_DIR="/etc/snort/rules"
COMMUNITY_FILE="$RULES_DIR/community.rules"
ET_URL="https://rules.emergingthreats.net/open/snort-2.9.0/emerging-all.rules"
BACKUP_FILE="$RULES_DIR/community.rules.bak"

echo "========================================"
echo "  UPDATE COMMUNITY RULES (Emerging Threats)"
echo "========================================"
echo "[*] Target: $COMMUNITY_FILE"
echo "[*] Source: Emerging Threats Open Rules"

# Backup rules lama
if [ -f "$COMMUNITY_FILE" ] && [ -s "$COMMUNITY_FILE" ]; then
    cp "$COMMUNITY_FILE" "$BACKUP_FILE"
    echo "[*] Backup rules lama: $BACKUP_FILE"
fi

echo "[*] Downloading rules dari Emerging Threats..."
echo "    URL: $ET_URL"

# Download dengan curl
HTTP_CODE=$(curl -w "%{http_code}" -fsSL \
    --connect-timeout 15 \
    --max-time 120 \
    -o "${COMMUNITY_FILE}.tmp" \
    "$ET_URL" 2>/tmp/curl-error.log)

if [ "$HTTP_CODE" = "200" ] && [ -s "${COMMUNITY_FILE}.tmp" ]; then
    # Sukses - ganti file
    mv "${COMMUNITY_FILE}.tmp" "$COMMUNITY_FILE"
    RULE_COUNT=$(grep -c "^alert\|^drop\|^log" "$COMMUNITY_FILE" 2>/dev/null || echo "0")
    echo "[✓] Update BERHASIL!"
    echo "[✓] Jumlah rules: $RULE_COUNT"
    echo "[✓] Tersimpan di: $COMMUNITY_FILE"
else
    echo "[!] Download gagal (HTTP: $HTTP_CODE)"
    cat /tmp/curl-error.log
    echo "[*] Menggunakan sample rules sebagai fallback..."

    # Fallback: buat minimal community rules untuk demo
    cat > "$COMMUNITY_FILE" << 'FALLBACK_RULES'
# Emerging Threats - Fallback Rules (offline/demo)
# Gunakan 'update-rules.sh' saat ada koneksi internet

# ET SCAN - Nmap OS Detection
alert tcp any any -> $HOME_NET any (msg:"ET SCAN Nmap OS Detection Probe"; flags:FPU; classtype:network-scan; priority:2; sid:2000001; rev:5;)

# ET DOS - UDP Flood
alert udp any any -> $HOME_NET any (msg:"ET DOS UDP Flood Attempt"; threshold:type both, track by_src, count 100, seconds 1; classtype:attempted-dos; priority:1; sid:2000002; rev:3;)

# ET WEB - Nikto Scanner
alert tcp any any -> $HTTP_SERVERS $HTTP_PORTS (msg:"ET WEB_SERVER Nikto Web Scanner"; flow:to_server,established; content:"Nikto"; http_user_agent; classtype:web-application-attack; priority:2; sid:2000003; rev:4;)

# ET EXPLOIT - shellshock
alert http any any -> $HOME_NET any (msg:"ET WEB_SERVER Possible Shellshock Exploit"; content:"() {"; http_header; classtype:attempted-admin; priority:1; sid:2000004; rev:6;)

# ET WEB - SQL Injection generic
alert http any any -> $HTTP_SERVERS $HTTP_PORTS (msg:"ET WEB_SERVER SQL Injection Attempt"; flow:established,to_server; content:"UNION"; nocase; content:"SELECT"; nocase; distance:0; classtype:web-application-attack; priority:1; sid:2000005; rev:7;)

# ET SCAN - Masscan
alert tcp any any -> $HOME_NET any (msg:"ET SCAN Masscan Port Scanner"; flags:S; threshold:type both, track by_src, count 50, seconds 2; classtype:network-scan; priority:2; sid:2000006; rev:2;)
FALLBACK_RULES

    echo "[*] Fallback rules ditulis ke $COMMUNITY_FILE"
fi

# Tampilkan statistik
echo ""
echo "========================================"
echo "  STATUS RULES"
echo "========================================"
echo "  Local rules   : $(grep -c "^alert" $RULES_DIR/local.rules 2>/dev/null || echo 0) rules"
echo "  Community rules: $(grep -c "^alert\|^drop" $RULES_DIR/community.rules 2>/dev/null || echo 0) rules"
echo "========================================"
echo ""
echo "[*] Restart Snort untuk menerapkan rules baru:"
echo "    pkill snort && sleep 2 && start-snort.sh"
