# PROJECT 3 - SNORT IDS + ACL
## Web Auth dengan Network Security
### erdi | Kali Linux

---

## ARSITEKTUR CONTAINER

```
172.20.0.0/24
├── 172.20.0.15  erdi-snort   (Snort IDS + iptables ACL)
├── 172.20.0.10  erdi-web     (Apache PHP HTTPS) ← dilindungi Snort
├── 172.20.0.20  erdi-db      (MySQL 8.0)        ← dilindungi Snort
└── 172.20.0.30  erdi-user    (Client/Testing)
```

---

## JALANKAN PROJECT

```bash
# Build dan jalankan semua container
docker compose up --build -d

# Lihat status container
docker compose ps

# Akses web
# HTTP  : http://localhost:8080  (redirect ke HTTPS)
# HTTPS : https://localhost:8443
```

---

## SNORT - PERINTAH PENTING

### Lihat alert realtime
```bash
docker exec erdi-snort tail -f /var/log/snort/alert.log
```

### Lihat critical alert saja
```bash
docker exec erdi-snort tail -f /var/log/snort/critical-alerts.log
```

### Toggle Rules (pertanyaan kisi-kisi)
```bash
# Lihat status rules
docker exec erdi-snort toggle-rules.sh status

# Aktifkan local rules saja
docker exec erdi-snort toggle-rules.sh local

# Coba matikan local rules
docker exec erdi-snort toggle-rules.sh community

# Ganti community rules = local rules dimatikan, community aktif
docker exec erdi-snort toggle-rules.sh community

# Aktifkan keduanya
docker exec erdi-snort toggle-rules.sh both
```

### Update Community Rules (Emerging Threats)
```bash
# Manual update rules dari internet
docker exec erdi-snort update-rules.sh

# Setelah update, restart snort
docker exec erdi-snort pkill snort
```

---

## ACL (iptables) - PERINTAH PENTING

### Lihat rules ACL aktif
```bash
docker exec erdi-snort iptables -L -v -n --line-numbers
```

### Lihat statistik paket yang di-DROP
```bash
docker exec erdi-snort iptables -L INPUT -v -n | grep DROP
```

### Reset dan re-apply ACL
```bash
docker exec erdi-snort setup-acl.sh
```

---

## UJIAN SNORT IDS

### Test semua sekaligus
```bash
docker exec erdi-snort test-acl.sh all
```

### Test spesifik
```bash
# Uji ICMP / ping
docker exec erdi-snort test-acl.sh icmp

# Uji HTTP/HTTPS
docker exec erdi-snort test-acl.sh http

# Uji blokir DB
docker exec erdi-snort test-acl.sh db

# Uji port scan (trigger Snort)
docker exec erdi-snort test-acl.sh scan

# Uji ICMP flood (trigger alert P1)
docker exec erdi-snort test-acl.sh flood
```

---

## SIMULASI SERANGAN DARI erdi-user

### Masuk ke container user
```bash
docker exec -it erdi-user bash
```

### Simulasi ICMP Flood (dari dalam container user)
```bash
# Ping biasa (tidak trigger flood)
ping -c 3 172.20.0.10

# ICMP Flood - trigger Snort SID 1000001 [P1]
ping -c 100 -i 0.01 172.20.0.10

# hping3 flood
hping3 --icmp -c 200 --faster 172.20.0.10
```

### Simulasi Port Scan
```bash
nmap -sS -T4 172.20.0.10
```

### Simulasi Brute Force Login
```bash
for i in $(seq 1 10); do
  curl -sk -X POST https://172.20.0.10/login.php \
    -d "username=admin&password=wrong$i" > /dev/null
  echo "Attempt $i"
done
```

### Coba akses DB langsung (harus diblok ACL)
```bash
nc -w 2 172.20.0.20 3306
# Expected: Connection refused / timeout
```

---

## PERTANYAAN KISI-KISI & JAWABAN

### "ICMP berapa?"
- Max ICMP yang diizinkan: **5 ping/detik** (ACL iptables)
- Threshold Snort alert: **10 ping dalam 1 detik** (local.rules SID 1000001)
- Priority: **P1 (Critical)**

### "Port berapa?"
| Port | Service | Status |
|------|---------|--------|
| 80   | HTTP    | ACCEPT (redirect ke 443) |
| 443  | HTTPS   | ACCEPT |
| 22   | SSH     | Rate-limited (max 3/menit) |
| 3306 | MySQL   | HANYA dari 172.20.0.10 |
| 53   | DNS     | ACCEPT |
| lainnya | -   | DROP |

### "ACL IBS + Firewall?"
- **IBS (Inbound Security)**: iptables INPUT chain, default DROP
- **Firewall**: state-based filtering, ESTABLISHED/RELATED ACCEPT
- **Rules**: lihat setup-acl.sh

### "Priority beragam 0,1,2,3?"
| Priority | Arti | Contoh |
|----------|------|--------|
| 0 | Informational | ICMP echo reply, DNS query |
| 1 | Critical/High | ICMP Flood, SQL Injection, SSH BruteForce |
| 2 | Medium/Warning | Port Scan, HTTP BruteForce, MySQL akses |
| 3 | Low/Info | Traffic normal berlebihan |

### "Coba ping Snort kirim notif otomatis?"
```bash
# Di terminal 1 - monitor notifikasi
docker exec erdi-snort tail -f /var/log/snort/critical-alerts.log

# Di terminal 2 - kirim flood dari user container
docker exec erdi-user ping -c 100 -i 0.01 172.20.0.15
```
→ Notifikasi muncul otomatis di terminal 1

---

## RULES SUMMARY

### Local Rules (local.rules)
| SID     | Deskripsi | Priority |
|---------|-----------|----------|
| 1000001 | ICMP Flood (>10/detik) | P1 |
| 1000002 | Ping ke WebServer | P1 |
| 1000003 | Ping ke Database | P1 |
| 1000004 | SSH Brute Force | P1 |
| 1000005 | SQL Injection HTTP | P1 |
| 1000006 | SQL Injection HTTPS | P1 |
| 1000007 | HTTP Login BruteForce | P2 |
| 1000008 | HTTPS Login BruteForce | P2 |
| 1000009 | Port Scan | P2 |
| 1000010 | Unauthorized MySQL | P2 |
| 1000011 | XSS Attempt | P2 |
| 1000012 | HTTP Traffic tinggi | P3 |
| 1000013 | HTTPS Traffic tinggi | P3 |
| 1000020 | ICMP Echo Reply keluar | P0 |
| 1000021 | DNS Query | P0 |
